"""
core/analyzer.py
All Anthropic API calls live here.
UI never calls the API directly — always goes through this module.

RAG FLOW:
  situation → laws_db.get_law_context_for_situation()
           → retrieved sections injected into prompt
           → Claude answers grounded in actual statute text
"""

import anthropic
from core.prompts import (
    ANALYSIS_SYSTEM_PROMPT,
    FOLLOWUP_SYSTEM_PROMPT,
    build_analysis_message,
    build_followup_message,
)
from core.laws_db import get_law_context_for_situation

MODEL = "claude-opus-4-6"
MAX_TOKENS_ANALYSIS = 4096
MAX_TOKENS_FOLLOWUP = 1024


class LegalAnalyzer:
    """
    Handles all Claude API interactions.
    Instantiate once with an API key and call analyze() / followup().
    """

    def __init__(self, api_key: str):
        self.client = anthropic.Anthropic(api_key=api_key)

    def analyze(self, situation: str) -> tuple[str, int]:
        """
        Main legal analysis with RAG.
        1. Retrieves relevant law sections from local JSON files.
        2. Injects them into the prompt.
        3. Claude answers grounded in the actual statute text.

        Returns (response_text, sections_found_count).
        Raises anthropic exceptions on failure — let UI handle them.
        """
        # ── Step 1: RAG — retrieve relevant law sections ──
        law_context = get_law_context_for_situation(situation)
        sections_count = law_context.count("Section") if law_context else 0

        # ── Step 2: Build grounded prompt ──
        user_message = build_analysis_message(situation, law_context)

        # ── Step 3: Call Claude ──
        response = self.client.messages.create(
            model=MODEL,
            max_tokens=MAX_TOKENS_ANALYSIS,
            system=ANALYSIS_SYSTEM_PROMPT,
            messages=[
                {"role": "user", "content": user_message}
            ],
        )
        return response.content[0].text, sections_count

    def followup(self, situation: str, previous_analysis: str, question: str) -> str:
        """Follow-up question on an existing analysis."""
        messages = build_followup_message(situation, previous_analysis, question)
        response = self.client.messages.create(
            model=MODEL,
            max_tokens=MAX_TOKENS_FOLLOWUP,
            system=FOLLOWUP_SYSTEM_PROMPT,
            messages=messages,
        )
        return response.content[0].text


def validate_api_key(api_key: str) -> tuple[bool, str]:
    """
    Quick validation of API key format before making a real call.
    Returns (is_valid, error_message).
    """
    if not api_key:
        return False, "API key is empty."
    if not api_key.startswith("sk-"):
        return False, "Invalid format. Key should start with 'sk-'."
    if len(api_key) < 20:
        return False, "Key seems too short. Please check it."
    return True, ""
