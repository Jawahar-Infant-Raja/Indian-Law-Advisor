"""
core/laws_db.py
RAG (Retrieval-Augmented Generation) engine for Indian laws.

Loads all law JSON files from the /laws folder.
Searches for relevant sections based on keywords in the user's situation.
Returns formatted law text to be injected into the Claude prompt.

This makes the AI answer from ACTUAL law text, not just training memory.
"""

import os
import json
import re
from pathlib import Path

LAWS_DIR = Path(__file__).parent.parent / "laws"
MAX_SECTIONS_TO_INJECT = 20   # Cap to avoid exceeding token limits
MIN_KEYWORD_SCORE = 1         # Minimum keyword matches to include a section


def _load_all_laws() -> list[dict]:
    """Load all JSON law files from the laws/ directory. Returns flat list of section dicts."""
    all_sections = []

    if not LAWS_DIR.exists():
        print(f"[LawsDB] Warning: laws directory not found at {LAWS_DIR}")
        return all_sections

    for json_file in sorted(LAWS_DIR.glob("*.json")):
        try:
            with open(json_file, "r", encoding="utf-8") as f:
                data = json.load(f)

            act_name  = data.get("act_name", json_file.stem)
            short_name = data.get("short_name", "")
            year       = data.get("year", "")

            for sec in data.get("sections", []):
                # Normalise — handle both single-act and multi-act JSONs
                entry = {
                    "act_name":   sec.get("act", act_name),
                    "short_name": short_name,
                    "year":       year,
                    "section":    sec.get("section", ""),
                    "title":      sec.get("title", ""),
                    "description": sec.get("description", ""),
                    "punishment": sec.get("punishment", ""),
                    "keywords":   [k.lower() for k in sec.get("keywords", [])],
                }
                all_sections.append(entry)

        except (json.JSONDecodeError, IOError) as e:
            print(f"[LawsDB] Error loading {json_file.name}: {e}")

    return all_sections


# Module-level cache — load once on first import
_LAW_SECTIONS: list[dict] = []


def _get_sections() -> list[dict]:
    global _LAW_SECTIONS
    if not _LAW_SECTIONS:
        _LAW_SECTIONS = _load_all_laws()
        print(f"[LawsDB] Loaded {len(_LAW_SECTIONS)} law sections from {LAWS_DIR}")
    return _LAW_SECTIONS


def _tokenise(text: str) -> list[str]:
    """Simple word tokeniser — lowercase, remove punctuation."""
    return re.findall(r'\b[a-z]{2,}\b', text.lower())


def search_relevant_sections(situation: str, max_results: int = MAX_SECTIONS_TO_INJECT) -> list[dict]:
    """
    Given a user's situation text, return the most relevant law sections.
    Scoring: keyword match count (each matching keyword = +2, each matching word = +1).
    Returns sections sorted by relevance score, descending.
    """
    sections  = _get_sections()
    situation_lower = situation.lower()
    situation_words = set(_tokenise(situation))

    scored = []
    for sec in sections:
        score = 0

        # 1. Direct keyword matches (high weight)
        for kw in sec["keywords"]:
            if kw in situation_lower:
                score += 2

        # 2. Title word matches
        for word in _tokenise(sec["title"]):
            if word in situation_words and len(word) > 3:
                score += 1

        # 3. Description word matches (lower weight)
        for word in _tokenise(sec["description"]):
            if word in situation_words and len(word) > 4:
                score += 0.5

        if score >= MIN_KEYWORD_SCORE:
            scored.append((score, sec))

    # Sort by score descending, then by act name for consistency
    scored.sort(key=lambda x: (-x[0], x[1]["act_name"]))

    return [sec for _, sec in scored[:max_results]]


def format_sections_for_prompt(sections: list[dict]) -> str:
    """
    Format retrieved sections into a clean text block for injection into the AI prompt.
    """
    if not sections:
        return ""

    lines = ["━━━ RELEVANT INDIAN LAW SECTIONS (Retrieved from local database) ━━━\n"]

    current_act = None
    for sec in sections:
        act = sec["act_name"]
        if act != current_act:
            lines.append(f"\n▶ {act}")
            if sec.get("year"):
                lines[-1] += f" ({sec['year']})"
            current_act = act

        lines.append(f"\n  Section {sec['section']} — {sec['title']}")
        lines.append(f"  {sec['description']}")
        if sec["punishment"] and sec["punishment"] != "N/A — definitional" and \
           sec["punishment"] != "N/A — procedural" and "N/A" not in sec["punishment"][:3]:
            lines.append(f"  ⚖️ Punishment: {sec['punishment']}")

    lines.append("\n━━━ END OF RETRIEVED SECTIONS ━━━")
    return "\n".join(lines)


def get_law_context_for_situation(situation: str) -> str:
    """
    Main entry point. Given a situation, returns formatted law context for the prompt.
    Returns empty string if no relevant sections found.
    """
    sections = search_relevant_sections(situation)
    if not sections:
        return ""
    return format_sections_for_prompt(sections)


def get_all_acts_summary() -> list[dict]:
    """Returns a summary of all loaded acts (for display/debug purposes)."""
    sections = _get_sections()
    seen = {}
    for sec in sections:
        key = sec["act_name"]
        if key not in seen:
            seen[key] = {"act_name": key, "short_name": sec["short_name"],
                         "year": sec["year"], "section_count": 0}
        seen[key]["section_count"] += 1
    return list(seen.values())


def reload_laws():
    """Force reload of all law JSON files (useful after adding new laws)."""
    global _LAW_SECTIONS
    _LAW_SECTIONS = []
    return _get_sections()
