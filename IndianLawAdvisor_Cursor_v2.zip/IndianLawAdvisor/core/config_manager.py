"""
core/config_manager.py
All config file (config.json) operations go through here.
Never read/write config.json directly from UI code.
"""

import json
import os
from datetime import datetime

CONFIG_FILE = "config.json"
MAX_HISTORY = 50

DEFAULT_CONFIG = {
    "api_key": "",
    "theme": "dark",
    "history": [],
    "window_geometry": "1200x820",
}


def load_config() -> dict:
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                # Merge with defaults for any missing keys
                return {**DEFAULT_CONFIG, **data}
        except (json.JSONDecodeError, IOError):
            pass
    return DEFAULT_CONFIG.copy()


def save_config(config: dict) -> None:
    try:
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(config, f, indent=2, ensure_ascii=False)
    except IOError as e:
        print(f"[Config] Could not save config: {e}")


def save_history_entry(config: dict, situation: str, result: str) -> None:
    """Append a new history entry and enforce MAX_HISTORY limit."""
    entry = {
        "timestamp": datetime.now().strftime("%d %b %Y, %I:%M %p"),
        "situation": situation[:300],   # truncate for storage
        "result": result,
    }
    config.setdefault("history", []).append(entry)
    config["history"] = config["history"][-MAX_HISTORY:]
    save_config(config)


def get_history(config: dict) -> list:
    return config.get("history", [])


def clear_history(config: dict) -> None:
    config["history"] = []
    save_config(config)
