"""
Indian Law Advisor — Desktop App
Entry point. Run this file to start the app.

Usage:
    python main.py
"""

import customtkinter as ctk
from ui.app import IndianLawAdvisorApp
from core.config_manager import load_config


def main():
    config = load_config()

    # Apply saved theme before creating window
    ctk.set_appearance_mode(config.get("theme", "dark"))
    ctk.set_default_color_theme("blue")

    app = IndianLawAdvisorApp(config)
    app.mainloop()


if __name__ == "__main__":
    main()
