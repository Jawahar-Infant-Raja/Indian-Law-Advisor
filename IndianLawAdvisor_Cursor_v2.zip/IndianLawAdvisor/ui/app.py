"""
ui/app.py
Main application window.
Wires UI components to core logic. Keeps UI and business logic separated.
"""

import threading
import customtkinter as ctk
import anthropic

from core.analyzer import LegalAnalyzer, validate_api_key
from core.config_manager import save_config, save_history_entry
from ui import theme as T
from ui.components import StatusBar, ApiKeyBar, ResultBox


WELCOME_TEXT = """\
Welcome to Indian Law Advisor 🇮🇳

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
HOW TO GET STARTED
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1️⃣  Paste your Anthropic API key above → Save Key
2️⃣  Describe your legal situation in detail
3️⃣  Click  🔍 Analyze My Situation

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
WHAT YOU GET
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
• Exact Indian laws & section numbers
• Your legal rights explained clearly
• All available remedies
• Step-by-step next actions
• Time limits for filing
• Whom to contact

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
GET A FREE API KEY
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
→  https://console.anthropic.com
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"""


class IndianLawAdvisorApp(ctk.CTk):

    def __init__(self, config: dict):
        super().__init__()
        self.config = config
        self.is_loading = False
        self._last_result = ""
        self._last_situation = ""

        self._setup_window()
        self._build_ui()
        self._load_saved_key()

    # ── Window Setup ────────────────────────────────────────
    def _setup_window(self):
        self.title("Indian Law Advisor")
        self.geometry(self.config.get("window_geometry", "1200x820"))
        self.minsize(960, 680)
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ── UI Construction ─────────────────────────────────────
    def _build_ui(self):
        root = ctk.CTkFrame(self, fg_color="transparent")
        root.grid(row=0, column=0, sticky="nsew", padx=16, pady=16)
        root.grid_columnconfigure(0, weight=1)
        root.grid_rowconfigure(2, weight=1)

        self._build_header(root)
        self._build_api_bar(root)
        self._build_content(root)
        self._build_status(root)

    def _build_header(self, parent):
        hdr = ctk.CTkFrame(parent, fg_color=(T.LIGHT_CARD, "#12294d"), corner_radius=T.RADIUS_LG)
        hdr.grid(row=0, column=0, sticky="ew", pady=(0, 10))
        hdr.grid_columnconfigure(1, weight=1)

        ctk.CTkLabel(hdr, text="⚖️", font=ctk.CTkFont(size=38)).grid(
            row=0, column=0, padx=(T.PAD_LG, T.PAD_SM), pady=14
        )

        text_col = ctk.CTkFrame(hdr, fg_color="transparent")
        text_col.grid(row=0, column=1, sticky="w")
        ctk.CTkLabel(text_col, text="Indian Law Advisor", font=T.font_title(),
                     text_color=(T.PRIMARY, "#90b8e8")).pack(anchor="w")
        ctk.CTkLabel(text_col,
                     text="Describe your situation — get the exact law, your rights & next steps",
                     font=T.font_small(), text_color=(T.LIGHT_MUTED, T.DARK_MUTED)).pack(anchor="w")

        ctk.CTkButton(
            hdr, text="🌙", width=40, height=40, corner_radius=T.RADIUS_PILL,
            fg_color="transparent", hover_color=(T.LIGHT_BORDER, T.DARK_CARD),
            font=ctk.CTkFont(size=18), command=self._toggle_theme,
        ).grid(row=0, column=2, padx=T.PAD_MD)

    def _build_api_bar(self, parent):
        self.api_bar = ApiKeyBar(parent, on_save=self._handle_save_key)
        self.api_bar.grid(row=1, column=0, sticky="ew", pady=(0, 10))

    def _build_content(self, parent):
        content = ctk.CTkFrame(parent, fg_color="transparent")
        content.grid(row=2, column=0, sticky="nsew")
        content.grid_columnconfigure(0, weight=5)
        content.grid_columnconfigure(1, weight=7)
        content.grid_rowconfigure(0, weight=1)

        self._build_left_panel(content)
        self._build_right_panel(content)

    def _build_left_panel(self, parent):
        left = ctk.CTkFrame(parent, corner_radius=T.RADIUS_LG)
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        left.grid_columnconfigure(0, weight=1)
        left.grid_rowconfigure(1, weight=1)

        ctk.CTkLabel(left, text="📝  Your Situation", font=T.font_label()).grid(
            row=0, column=0, sticky="w", padx=T.PAD_MD, pady=(T.PAD_MD, T.PAD_SM)
        )

        # Situation input
        self.situation_box = ctk.CTkTextbox(
            left, font=T.font_body(), wrap="word", corner_radius=T.RADIUS_MD
        )
        self.situation_box.grid(row=1, column=0, sticky="nsew", padx=T.PAD_MD, pady=(0, T.PAD_SM))
        self.situation_box.insert("0.0", T.PLACEHOLDER)
        self.situation_box.bind("<FocusIn>", self._clear_placeholder)

        # Category buttons
        self._build_category_bar(left)

        # Action buttons
        self.analyze_btn = ctk.CTkButton(
            left, text="🔍  Analyze My Situation",
            font=T.font_btn_lg(), height=46, corner_radius=T.RADIUS_MD,
            fg_color=T.PRIMARY, hover_color=T.PRIMARY_HOVER,
            command=self._on_analyze,
        )
        self.analyze_btn.grid(row=4, column=0, sticky="ew", padx=T.PAD_MD, pady=(0, T.PAD_SM))

        ctk.CTkButton(
            left, text="Clear", height=32, corner_radius=T.RADIUS_MD,
            fg_color="transparent", border_width=1,
            hover_color=(T.LIGHT_CARD, T.DARK_CARD),
            font=T.font_body(), command=self._clear_all,
        ).grid(row=5, column=0, sticky="ew", padx=T.PAD_MD, pady=(0, T.PAD_MD))

    def _build_category_bar(self, parent):
        bar = ctk.CTkScrollableFrame(parent, height=40, fg_color="transparent", orientation="horizontal")
        bar.grid(row=2, column=0, sticky="ew", padx=T.PAD_MD, pady=(0, T.PAD_SM))

        for label, starter in T.CATEGORIES:
            ctk.CTkButton(
                bar, text=label, height=30, corner_radius=T.RADIUS_PILL,
                fg_color=(T.LIGHT_CARD, T.DARK_CARD),
                hover_color=(T.LIGHT_BORDER, T.DARK_BORDER),
                text_color=(T.PRIMARY, "#90b8e8"),
                font=T.font_small(),
                command=lambda s=starter: self._fill_category(s),
            ).pack(side="left", padx=3)

        # Character counter row
        self.char_count = ctk.CTkLabel(
            parent, text="0 chars", font=T.font_small(),
            text_color=(T.LIGHT_MUTED, T.DARK_MUTED), anchor="e"
        )
        self.char_count.grid(row=3, column=0, sticky="e", padx=T.PAD_MD, pady=(0, T.PAD_SM))
        self.situation_box.bind("<KeyRelease>", self._update_char_count)

    def _build_right_panel(self, parent):
        self.result_box = ResultBox(parent)
        self.result_box.grid(row=0, column=1, sticky="nsew")
        self.result_box.set_text(WELCOME_TEXT)

    def _build_status(self, parent):
        self.status = StatusBar(parent)
        self.status.grid(row=3, column=0, sticky="w", pady=(8, 0))
        self.status.set(f"Ready  •  Indian Law Advisor  •  Model: claude-opus-4-6")

    # ── Event Handlers ───────────────────────────────────────
    def _on_close(self):
        self.config["window_geometry"] = self.geometry()
        save_config(self.config)
        self.destroy()

    def _toggle_theme(self):
        new = "light" if ctk.get_appearance_mode() == "Dark" else "dark"
        ctk.set_appearance_mode(new)
        self.config["theme"] = new
        save_config(self.config)

    def _clear_placeholder(self, _event):
        current = self.situation_box.get("0.0", "end").strip()
        if current == T.PLACEHOLDER.strip():
            self.situation_box.delete("0.0", "end")

    def _fill_category(self, starter: str):
        self.situation_box.delete("0.0", "end")
        self.situation_box.insert("0.0", starter)
        self.situation_box.focus()

    def _clear_all(self):
        self.situation_box.delete("0.0", "end")
        self.result_box.set_text("Cleared. Describe your situation and click Analyze.")
        self.status.set("Cleared.", "default")

    def _update_char_count(self, _event):
        count = len(self.situation_box.get("0.0", "end").strip())
        self.char_count.configure(text=f"{count} chars")

    def _handle_save_key(self, key: str):
        valid, err = validate_api_key(key)
        if not valid:
            self.status.set(f"⚠️  {err}", "error")
            return
        self.config["api_key"] = key
        save_config(self.config)
        self.status.set("API key saved ✓", "success")

    def _load_saved_key(self):
        key = self.config.get("api_key", "")
        if key:
            self.api_bar.set_key(key)
            self.status.set("API key loaded ✓  —  Ready to analyze.", "success")

    # ── Analysis Flow ────────────────────────────────────────
    def _on_analyze(self):
        if self.is_loading:
            return

        api_key = self.api_bar.entry.get().strip()
        valid, err = validate_api_key(api_key)
        if not valid:
            self.result_box.set_text(f"❌  {err}\n\nGet a free key at:\nhttps://console.anthropic.com")
            self.status.set(f"⚠️  {err}", "error")
            return

        situation = self.situation_box.get("0.0", "end").strip()
        if len(situation) < 20 or situation == T.PLACEHOLDER.strip():
            self.result_box.set_text("❌  Please describe your situation in more detail (at least a sentence or two).")
            self.status.set("⚠️  Situation too short.", "warning")
            return

        self._start_loading(situation, api_key)

    def _start_loading(self, situation: str, api_key: str):
        self.is_loading = True
        self._last_situation = situation
        self.analyze_btn.configure(text="⏳  Analyzing...", state="disabled")
        self.result_box.set_text(
            "🔍  Analyzing your situation...\n\n"
            "The AI is identifying all applicable Indian laws,\n"
            "your rights, remedies, and next steps.\n\n"
            "This usually takes 10–20 seconds."
        )
        self.status.set("🔍  Analyzing...", "info")

        thread = threading.Thread(
            target=self._run_analysis,
            args=(api_key, situation),
            daemon=True,
        )
        thread.start()

    def _run_analysis(self, api_key: str, situation: str):
        try:
            analyzer = LegalAnalyzer(api_key)
            result, sections_count = analyzer.analyze(situation)
            self._last_result = result
            save_history_entry(self.config, situation, result)
            self.after(0, lambda: self._show_success(result, sections_count))

        except anthropic.AuthenticationError:
            self.after(0, lambda: self._show_error(
                "❌  Invalid API Key\n\nYour key was rejected. Please check it.\n"
                "→  https://console.anthropic.com"
            ))
        except anthropic.RateLimitError:
            self.after(0, lambda: self._show_error(
                "❌  Rate Limit\n\nToo many requests. Please wait a moment and try again."
            ))
        except anthropic.APIConnectionError:
            self.after(0, lambda: self._show_error(
                "❌  No Internet Connection\n\nThis app needs internet to call the Claude API.\n"
                "Please check your connection."
            ))
        except Exception as exc:
            self.after(0, lambda: self._show_error(f"❌  Unexpected Error\n\n{exc}"))

    def _show_success(self, result: str, sections_count: int = 0):
        self.is_loading = False
        self.analyze_btn.configure(text="🔍  Analyze My Situation", state="normal")
        self.result_box.set_text(result)
        rag_note = f"  •  {sections_count} law sections referenced" if sections_count else ""
        self.status.set(f"✅  Analysis complete{rag_note}", "success")

    def _show_error(self, message: str):
        self.is_loading = False
        self.analyze_btn.configure(text="🔍  Analyze My Situation", state="normal")
        self.result_box.set_text(message)
        self.status.set("❌  Error occurred.", "error")
