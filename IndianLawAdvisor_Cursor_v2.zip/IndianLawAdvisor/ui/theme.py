"""
ui/theme.py
Single source of truth for all colors, fonts, and design tokens.
Change the look of the entire app by editing this file.
"""

import customtkinter as ctk

# ── Brand Colors ─────────────────────────────────────────────
PRIMARY       = "#1B4F8A"   # Deep blue — Indian legal/government feel
PRIMARY_HOVER = "#153d6e"
PRIMARY_LIGHT = "#2E75B6"

ACCENT        = "#f59e0b"   # Amber — highlights, warnings
SUCCESS       = "#22c55e"   # Green — success states
ERROR         = "#ef4444"   # Red — errors
WARNING       = "#f59e0b"   # Amber — warnings
INFO          = "#3b82f6"   # Blue — info

# ── Light Theme ──────────────────────────────────────────────
LIGHT_BG      = "#f0f4f8"
LIGHT_SURFACE = "#ffffff"
LIGHT_CARD    = "#e8f0fb"
LIGHT_BORDER  = "#cbd5e1"
LIGHT_TEXT    = "#1e293b"
LIGHT_MUTED   = "#64748b"

# ── Dark Theme ───────────────────────────────────────────────
DARK_BG       = "#0f1724"
DARK_SURFACE  = "#1a2540"
DARK_CARD     = "#1e3055"
DARK_BORDER   = "#2d4a70"
DARK_TEXT      = "#e2e8f0"
DARK_MUTED    = "#94a3b8"

# ── Radii ────────────────────────────────────────────────────
RADIUS_SM  = 6
RADIUS_MD  = 10
RADIUS_LG  = 14
RADIUS_PILL = 24

# ── Fonts ────────────────────────────────────────────────────
def font_title():    return ctk.CTkFont("Georgia", 26, "bold")
def font_heading():  return ctk.CTkFont("Georgia", 18, "bold")
def font_label():    return ctk.CTkFont("Segoe UI", 13, "bold")
def font_body():     return ctk.CTkFont("Segoe UI", 13)
def font_small():    return ctk.CTkFont("Segoe UI", 11)
def font_mono():     return ctk.CTkFont("Consolas", 13)
def font_btn():      return ctk.CTkFont("Segoe UI", 13, "bold")
def font_btn_lg():   return ctk.CTkFont("Segoe UI", 15, "bold")

# ── Spacing ──────────────────────────────────────────────────
PAD_XS  = 4
PAD_SM  = 8
PAD_MD  = 14
PAD_LG  = 20
PAD_XL  = 28

# ── Category Quick-Fill Data ─────────────────────────────────
CATEGORIES = [
    ("🏠 Property",  "My landlord / neighbour issue: "),
    ("👨‍👩‍👧 Family",   "My family law issue (marriage / divorce / inheritance): "),
    ("💼 Workplace", "My employer has not paid salary / harassed me at work: "),
    ("🛒 Consumer",  "I was cheated by a company / product / service: "),
    ("📱 Cyber",     "I am a victim of online fraud / cyber harassment: "),
    ("🚗 Accident",  "I was in a road accident and need to know my rights: "),
    ("🏦 Finance",   "A bank / lender / investor has cheated me: "),
]

# ── Example Situations ───────────────────────────────────────
PLACEHOLDER = (
    "Describe your situation in detail...\n\n"
    "Example: My landlord has not returned my ₹50,000 security deposit "
    "after 3 months of vacating the house. He is also threatening me. "
    "What are my legal rights and what can I do?"
)
