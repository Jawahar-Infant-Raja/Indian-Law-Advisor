"""
ui/components.py
Reusable custom widgets.
Add new shared UI components here so app.py stays clean.
"""

import customtkinter as ctk
from ui import theme as T


class StatusBar(ctk.CTkLabel):
    """Bottom status bar with color-coded messages."""

    def __init__(self, parent, **kwargs):
        super().__init__(
            parent,
            text="Ready",
            font=T.font_small(),
            text_color=T.DARK_MUTED,
            anchor="w",
            **kwargs,
        )

    def set(self, message: str, state: str = "default"):
        colors = {
            "success": T.SUCCESS,
            "error":   T.ERROR,
            "warning": T.WARNING,
            "info":    T.INFO,
            "default": T.DARK_MUTED,
        }
        self.configure(text=message, text_color=colors.get(state, T.DARK_MUTED))


class SectionCard(ctk.CTkFrame):
    """A titled card container used throughout the layout."""

    def __init__(self, parent, title: str = "", **kwargs):
        super().__init__(parent, corner_radius=T.RADIUS_LG, **kwargs)
        self.grid_columnconfigure(0, weight=1)

        if title:
            ctk.CTkLabel(
                self,
                text=title,
                font=T.font_label(),
                anchor="w",
            ).grid(row=0, column=0, sticky="w", padx=T.PAD_MD, pady=(T.PAD_MD, T.PAD_SM))

        self._next_row = 1 if title else 0

    def add(self, widget, **grid_kwargs):
        defaults = dict(row=self._next_row, column=0, sticky="ew",
                        padx=T.PAD_MD, pady=(0, T.PAD_SM))
        defaults.update(grid_kwargs)
        widget.grid(**defaults)
        self._next_row += 1
        return widget


class ApiKeyBar(ctk.CTkFrame):
    """API key input row with save + visibility toggle."""

    def __init__(self, parent, on_save=None, **kwargs):
        super().__init__(parent, corner_radius=T.RADIUS_MD, **kwargs)
        self.grid_columnconfigure(1, weight=1)
        self._on_save = on_save
        self._visible = False

        ctk.CTkLabel(self, text="🔑  API Key:", font=T.font_label()).grid(
            row=0, column=0, padx=(T.PAD_MD, T.PAD_SM), pady=10
        )

        self.entry = ctk.CTkEntry(
            self,
            placeholder_text="Enter your Anthropic API key  (sk-ant-...)",
            show="•",
            font=T.font_body(),
            height=36,
        )
        self.entry.grid(row=0, column=1, sticky="ew", padx=(0, T.PAD_SM), pady=10)

        ctk.CTkButton(
            self, text="👁", width=36, height=36, corner_radius=T.RADIUS_MD,
            fg_color="transparent", hover_color=(T.LIGHT_CARD, T.DARK_CARD),
            font=ctk.CTkFont(size=16), command=self._toggle_visibility,
        ).grid(row=0, column=2, padx=(0, T.PAD_SM))

        ctk.CTkButton(
            self, text="Save Key", width=90, height=36, corner_radius=T.RADIUS_MD,
            font=T.font_btn(), fg_color=T.PRIMARY, hover_color=T.PRIMARY_HOVER,
            command=self._save,
        ).grid(row=0, column=3, padx=(0, T.PAD_MD))

    def _toggle_visibility(self):
        self._visible = not self._visible
        self.entry.configure(show="" if self._visible else "•")

    def _save(self):
        if self._on_save:
            self._on_save(self.entry.get().strip())

    def set_key(self, key: str):
        self.entry.delete(0, "end")
        self.entry.insert(0, key)


class ResultBox(ctk.CTkFrame):
    """Right-side result display with copy button."""

    def __init__(self, parent, **kwargs):
        super().__init__(parent, corner_radius=T.RADIUS_LG, **kwargs)
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # Header row
        header = ctk.CTkFrame(self, fg_color="transparent")
        header.grid(row=0, column=0, sticky="ew", padx=T.PAD_MD, pady=(T.PAD_MD, T.PAD_SM))
        header.grid_columnconfigure(0, weight=1)

        ctk.CTkLabel(header, text="⚖️  Legal Analysis", font=T.font_label()).grid(
            row=0, column=0, sticky="w"
        )
        ctk.CTkButton(
            header, text="📋 Copy", width=80, height=28, corner_radius=T.RADIUS_MD,
            fg_color="transparent", border_width=1,
            hover_color=(T.LIGHT_CARD, T.DARK_CARD),
            font=T.font_small(), command=self._copy,
        ).grid(row=0, column=1, sticky="e")

        # Text area
        self.textbox = ctk.CTkTextbox(
            self, font=T.font_mono(), wrap="word",
            corner_radius=T.RADIUS_MD, state="disabled",
        )
        self.textbox.grid(row=1, column=0, sticky="nsew", padx=T.PAD_MD, pady=(0, T.PAD_MD))

    def set_text(self, text: str):
        self.textbox.configure(state="normal")
        self.textbox.delete("0.0", "end")
        self.textbox.insert("0.0", text)
        self.textbox.configure(state="disabled")

    def get_text(self) -> str:
        return self.textbox.get("0.0", "end").strip()

    def _copy(self):
        text = self.get_text()
        if text:
            self.clipboard_clear()
            self.clipboard_append(text)
